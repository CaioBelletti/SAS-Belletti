from django.apps import AppConfig


class AprovacoesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "aprovacoes"
    verbose_name = "Aprovações"
