from django.apps import AppConfig


class CozinhaConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "cozinha"
    verbose_name = "Cozinha"
